& escript.exe bootstrap @args
